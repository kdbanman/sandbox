update Rent
set rentmode = 'L'
where rentmode = 'S' and (sysdate - since) > 7;